# Configuración global (ejemplo)
DEBUG = True
