---
name: Documentation
about: Create a report about some aspect of the project
title: "[DOC]"
labels: ''
assignees: ''

---

**Describe the report**
A clear and concise description of what the document must include.

**Deadline**
When the document should be finisehd and uploaded.

**Depends on**
What other issues must be completed before starting this one.

**Additional context**
Add any other context about the document here.
