---
name: Feature
about: Suggest an idea for this project
title: "[FEATURE]"
labels: ''
assignees: ''

---

**Describe the addition to the project you'd like**
A clear and concise description of what you want to happen.

**Deadline**
When the feature should be implemented.

**Depends on**
What other issues must be completed before starting this one.

**Additional context**
Add any other context or screenshots about the feature request here.
